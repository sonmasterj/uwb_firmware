#include "sdk_config.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "bsp.h"
#include "boards.h"
#include "nordic_common.h"
#include "nrf_drv_clock.h"
#include "nrf_drv_spi.h"
#include "nrf_uart.h"
#include "app_util_platform.h"
#include "nrf_gpio.h"
#include "nrf_delay.h"
#include "nrf_log.h"
#include "nrf.h"
#include "app_error.h"
#include "app_util_platform.h"
#include "app_error.h"
#include <string.h>
#include "port_platform.h"
#include "deca_types.h"
#include "deca_param_types.h"
#include "deca_regs.h"
#include "deca_device_api.h"
#include "SEGGER_RTT.h"
#include "uart.h"
#include "nrf_drv_gpiote.h"
#include "fds.h"
#include "nrf_fstorage.h"
#define FILE_ID     0x1111
#define REC_KEY     0x2222
static ret_code_t kls_fds_write(uint32_t write_file_id, uint32_t write_record_key , uint8_t write_data[])
{		
		static uint8_t m_deadbeef[10] = {0};
		
		memcpy(m_deadbeef, write_data, sizeof(m_deadbeef));
		
		fds_record_t        record;
		fds_record_desc_t   record_desc;
	
		// Set up record.
		record.file_id              = write_file_id;
		record.key              		= write_record_key;
		record.data.p_data       		= &m_deadbeef;
		record.data.length_words   	= sizeof(m_deadbeef)/sizeof(uint8_t);
				
		ret_code_t ret = fds_record_write(&record_desc, &record);
		if (ret != FDS_SUCCESS)
		{
				return ret;
		}
		 printf("Writing Record ID = %d \r\n",record_desc.record_id);
		return NRF_SUCCESS;
	
}
	
static ret_code_t kls_fds_read(uint32_t read_file_id, uint32_t relevant_record_key , uint8_t read_data[])
{	
		fds_flash_record_t  flash_record;
		fds_record_desc_t   record_desc;
		fds_find_token_t    ftok ={0};//Important, make sure you zero init the ftok token
		uint8_t *data;
		uint32_t err_code;
		
		printf("Start searching... \r\n");
		// Loop until all records with the given key and file ID have been found.
		while (fds_record_find(read_file_id, relevant_record_key, &record_desc, &ftok) == FDS_SUCCESS)
		{
				err_code = fds_record_open(&record_desc, &flash_record);
				if ( err_code != FDS_SUCCESS)
				{
					return err_code;		
				}
				
				printf("Found Record ID = %d\r\n",record_desc.record_id);

				data = (uint8_t *) flash_record.p_data;
				for (uint8_t i=0;i<flash_record.p_header->length_words;i++)
				{
					read_data[i] = data[i];
				}
			
		
				//NRF_LOG_HEXDUMP_INFO(read_data, sizeof(read_data));
				// Access the record through the flash_record structure.
				// Close the record when done.
				err_code = fds_record_close(&record_desc);
				if (err_code != FDS_SUCCESS)
				{
					return err_code;	
				}
		}
		return NRF_SUCCESS;	
}

int main()
{
  boUART_Init();
  uint8 data_write[]={1,2};
  uint8 data_read[2];
  kls_fds_write(FILE_ID,REC_KEY,data_write);
  kls_fds_read(FILE_ID,REC_KEY,data_read);
  printf("%d\n\r",data_read[0]);
}